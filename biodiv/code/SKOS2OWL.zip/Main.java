/******************************************************************************
* @author Daniel Faria                  									  *
******************************************************************************/
package skos2owl;

import java.io.File;
import java.util.Map;
import java.util.Set;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.vocab.OWLRDFVocabulary;

public class Main
{
	private static OWLOntologyManager manager;
	private static OWLDataFactory factory;
	private static final String LIMIT = "entityExpansionLimit"; 


	public static void main(String[] args) throws Exception
	{
		String inputPath = "";
		String outputPath = "";
		//Read the arguments
		for(int i = 0; i < args.length; i++)
		{
			if((args[i].equalsIgnoreCase("-i") || args[i].equalsIgnoreCase("--input")) && i+1 < args.length)
				inputPath = args[++i];
			else if((args[i].equalsIgnoreCase("-o") || args[i].equalsIgnoreCase("--output")) && i+1 < args.length)
				outputPath = args[++i];
		}
		//Check that the necessary arguments are given and that the files can be found
		if(inputPath.isEmpty())
		{
			System.out.println("ERROR: You must specify an input SKOS thesaurus file using the -i option");
			System.exit(1);
		}
		if(outputPath.isEmpty())
		{
			System.out.println("ERROR: You must specify an output ontology file using the -o option");
			System.exit(1);
		}
		File s = new File(inputPath);
		if(!s.canRead())
		{
			System.out.println("ERROR: Input SKOS thesaurus file not found");
			System.exit(1);
		}
		IRI t = IRI.create(new File(outputPath));
		
		//Increase the entity expansion limit to allow large ontologies
		System.setProperty(LIMIT, "1000000");
		//Get an Ontology Manager and Data Factory
		manager = OWLManager.createOWLOntologyManager();
		factory = manager.getOWLDataFactory();
		//Load the local ontology
		File f = new File(inputPath);
		OWLOntology skos = manager.loadOntologyFromOntologyDocument(f);
		System.out.println("Loaded SKOS thesaurus");
		System.out.println("Classes: " +  skos.getClassesInSignature().size());
		System.out.println("Individuals: " + skos.getIndividualsInSignature().size());
		if(!skos.containsClassInSignature(SKOS.CONCEPT.toIRI()))
		{
			System.out.println("ERROR: skos:concept class not detected; please make sure you load a valid SKOS thesaurus");
			System.exit(1);
		}
		OWLOntology owl = manager.createOntology(t);

		//Create necessary properties in OWL
		OWLAnnotationProperty synonym = factory.getOWLAnnotationProperty(IRI.create("http://www.geneontology.org/formats/oboInOwl#hasRelatedSynonym"));
		OWLAnnotationProperty hidden = factory.getOWLAnnotationProperty(SKOS.HIDDEN_LABEL.toIRI());
		OWLObjectProperty related = factory.getOWLObjectProperty(SKOS.RELATED.toIRI());
		OWLObjectProperty semantic = factory.getOWLObjectProperty(SKOS.SEMANTIC_REL.toIRI());
		
		//Add them to the owl ontology
		manager.addAxiom(owl, factory.getOWLDeclarationAxiom(synonym));
		manager.addAxiom(owl, factory.getOWLDeclarationAxiom(hidden));
		manager.addAxiom(owl, factory.getOWLDeclarationAxiom(related));
		manager.addAxiom(owl, factory.getOWLDeclarationAxiom(semantic));
		//Both object properties should be symmetric
		manager.addAxiom(owl, factory.getOWLSymmetricObjectPropertyAxiom(related));
		manager.addAxiom(owl, factory.getOWLSymmetricObjectPropertyAxiom(semantic));
		
		
		//Get all SKOS concepts and convert them into classes
		OWLClass concept = factory.getOWLClass(SKOS.CONCEPT.toIRI());
		Set<OWLIndividual> indivs = concept.getIndividuals(skos);
		for(OWLClassExpression c : concept.getSubClasses(skos))
			if(c instanceof OWLClass)
				indivs.addAll(c.asOWLClass().getIndividuals(skos));
		for(OWLIndividual i : indivs)
		{
			if(!i.isNamed())
				continue;
			OWLNamedIndividual ind = i.asOWLNamedIndividual();
			IRI indIRI = ind.getIRI();
			manager.addAxiom(owl, factory.getOWLDeclarationAxiom(factory.getOWLClass(indIRI)));
			
			//Convert concepts' annotations
			Set<OWLAnnotation> annots = ind.getAnnotations(skos);
			for(OWLAnnotation annotation : annots)
			{
				IRI propIRI = annotation.getProperty().getIRI();
				if(propIRI.equals(SKOS.PREFLABEL.toIRI()))
				{
					manager.addAxiom(owl, factory.getOWLAnnotationAssertionAxiom(indIRI,
							factory.getOWLAnnotation(
									factory.getOWLAnnotationProperty(OWLRDFVocabulary.RDFS_LABEL.getIRI()),
									annotation.getValue())));
				}
				else if(propIRI.equals(SKOS.ALTLABEL.toIRI()))
				{
					manager.addAxiom(owl, factory.getOWLAnnotationAssertionAxiom(indIRI,
							factory.getOWLAnnotation(synonym,annotation.getValue())));
				}
				else if(propIRI.equals(SKOS.HIDDEN_LABEL.toIRI()))
				{
					manager.addAxiom(owl, factory.getOWLAnnotationAssertionAxiom(indIRI,
							factory.getOWLAnnotation(hidden,annotation.getValue())));
				}
				else if(propIRI.equals(SKOS.SCOPE_NOTE.toIRI()) || propIRI.equals(SKOS.NOTATION.toIRI()) || propIRI.equals(SKOS.DEFINITION.toIRI()))
				{
					manager.addAxiom(owl, factory.getOWLAnnotationAssertionAxiom(indIRI,
							factory.getOWLAnnotation(
									factory.getOWLAnnotationProperty(OWLRDFVocabulary.RDFS_COMMENT.getIRI()),
									annotation.getValue())));
				}
			}
		}

		//Now for the relations between concepts
		//For simplicity, we convert "broader", "broader_transitive", "narrower" and "narrower_transitive" to subclass relationships
		//We treat "related" and "semantic relation" as someValues restrictions on the corresponding properties
		for(OWLIndividual i : indivs)
		{
			if(!i.isNamed())
				continue;
			OWLClass c1 = factory.getOWLClass(i.asOWLNamedIndividual().getIRI());
			
			//Check if the skos thesaurus has the object properties declared
			if(skos.containsObjectPropertyInSignature(SKOS.BROADER.toIRI()))
			{
				//If so, we can retrieve the Object Properties of each concept
				Map<OWLObjectPropertyExpression, Set<OWLIndividual>> iProps = i.getObjectPropertyValues(skos);
				for(OWLObjectPropertyExpression prop : iProps.keySet())
				{
					if(prop.isAnonymous())
						continue;
					//Get each property's IRI
					IRI rel = prop.asOWLObjectProperty().getIRI();
					if(rel.equals(SKOS.NARROWER.toIRI()) || rel.equals(SKOS.NARROWER_TRANS.toIRI()))
					{
						for(OWLIndividual p : iProps.get(prop))
						{
							if(!p.isNamed())
								continue;
							OWLClass c2 = factory.getOWLClass(p.asOWLNamedIndividual().getIRI());
							manager.addAxiom(owl, factory.getOWLSubClassOfAxiom(c2, c1));
						}
					}
					else if(rel.equals(SKOS.BROADER.toIRI()) || rel.equals(SKOS.BROADER_TRANS.toIRI()))
					{
						for(OWLIndividual p : iProps.get(prop))
						{
							if(!p.isNamed())
								continue;
							OWLClass c2 = factory.getOWLClass(p.asOWLNamedIndividual().getIRI());
							manager.addAxiom(owl, factory.getOWLSubClassOfAxiom(c1, c2));
						}
					}
					else if(rel.equals(SKOS.RELATED.toIRI()) || rel.equals(SKOS.SEMANTIC_REL.toIRI()))
					{
						for(OWLIndividual p : iProps.get(prop))
						{
							if(!p.isNamed())
								continue;
							OWLClass c2 = factory.getOWLClass(p.asOWLNamedIndividual().getIRI());
							factory.getOWLSubClassOfAxiom(c1, factory.getOWLObjectSomeValuesFrom(prop, c2));
						}						
					}
				}
			}
			//Otherwise, they will likely register as Annotation Properties
			else
			{
				//So we have to get them from the annotations
				for(OWLAnnotation p : i.asOWLNamedIndividual().getAnnotations(skos))
				{
					IRI rel = p.getProperty().getIRI();
					if(!rel.equals(SKOS.BROADER.toIRI()) && !rel.equals(SKOS.BROADER_TRANS.toIRI()) &&
							!rel.equals(SKOS.NARROWER.toIRI()) && !rel.equals(SKOS.BROADER_TRANS.toIRI()) &&
							!rel.equals(SKOS.RELATED.toIRI()) && !rel.equals(SKOS.SEMANTIC_REL.toIRI()))
						continue;
					OWLAnnotationValue v = p.getValue();
					if(!(v instanceof IRI))
						continue;
					
					OWLClass c2 = factory.getOWLClass(IRI.create(v.toString()));
					if(rel.equals(SKOS.BROADER.toIRI()) || rel.equals(SKOS.BROADER_TRANS.toIRI()))
						manager.addAxiom(owl, factory.getOWLSubClassOfAxiom(c1, c2));
					else if(rel.equals(SKOS.NARROWER.toIRI()) || rel.equals(SKOS.BROADER_TRANS.toIRI()))
						manager.addAxiom(owl, factory.getOWLSubClassOfAxiom(c1, c2));
					else
					{
						OWLObjectProperty prop = factory.getOWLObjectProperty(rel);
						factory.getOWLSubClassOfAxiom(c1, factory.getOWLObjectSomeValuesFrom(prop, c2));
					}
				}
			}
		}
		manager.saveOntology(owl, t);
	}
}